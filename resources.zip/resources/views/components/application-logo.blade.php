<img src="{{ asset('img/azul-maya.webp') }}" alt="Azul maya" width="500" height="500" {{$attributes}}/>
