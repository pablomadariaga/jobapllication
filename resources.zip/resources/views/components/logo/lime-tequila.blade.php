<img src="{{ asset('img/lime-tequila.webp') }}" alt="Lime tequila" width="550" height="550" {{$attributes}}/>
