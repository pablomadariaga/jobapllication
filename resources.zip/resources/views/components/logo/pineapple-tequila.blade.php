<img src="{{ asset('img/pineapple-tequila.webp') }}" alt="Pineapple tequila" width="550" height="550" {{$attributes}}/>
