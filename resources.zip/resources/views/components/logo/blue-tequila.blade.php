<img src="{{ asset('img/blue-tequila.webp') }}" alt="Blue tequila" width="550" height="550" {{$attributes}}/>
