<img src="{{ asset('img/pink-tequila.webp') }}" alt="Pink tequila" width="550" height="550" {{$attributes}}/>
