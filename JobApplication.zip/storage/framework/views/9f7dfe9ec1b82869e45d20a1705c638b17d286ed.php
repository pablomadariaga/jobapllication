<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['label' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['label' => '']); ?>
<?php foreach (array_filter((['label' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php
$id = $attributes->has('id') ? $attributes->get('id') : 'input'.rand(1, 999999999999)
?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['for' => ''.e($id).'','class' => 'flex items-center cursor-pointer']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => ''.e($id).'','class' => 'flex items-center cursor-pointer']); ?>
    <input type="radio" id="<?php echo e($id); ?>" <?php echo e(old($attributes->get('name'))==$attributes->get('value') ? 'checked' : ''); ?>

    <?php echo e($attributes->merge(['class'=>
    'form-radio rounded-full transition ease-in-out duration-100 '.
    'border-neutral-300 text-amber-600 focus:ring-amber-600 focus:border-amber-400 '.
    'dark:border-neutral-500 dark:checked:border-neutral-600 dark:focus:ring-neutral-600 '.
    'dark:focus:border-neutral-500 dark:bg-neutral-600 dark:text-neutral-600 '.
    'dark:focus:ring-offset-neutral-800 bg-opacity-60 dark:bg-opacity-50 mr-1'])); ?>>
    <?php echo e($label); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\JobApplication\resources\views/components/input/radio.blade.php ENDPATH**/ ?>