<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['label' => '', 'inline' => false, 'rules' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['label' => '', 'inline' => false, 'rules' => '']); ?>
<?php foreach (array_filter((['label' => '', 'inline' => false, 'rules' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php
$id = $attributes->has('id') ? $attributes->get('id') : 'input'.rand(1, 999999999999);
?>
<?php if($label): ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['for' => ''.e($id).'','inline' => $inline]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => ''.e($id).'','inline' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($inline)]); ?><?php echo e($label); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php endif; ?>
<input id="<?php echo e($id); ?>" data-rules="[<?php echo e($rules ?? ''); ?>]" <?php if($attributes->has('name') && trim($attributes->get('name'))!=
''): ?>
data-server-errors="[<?php $__errorArgs = [$attributes->get('name')];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>'<?php echo e(str($message)->ucFirst()->__toString()); ?>'<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>]"
x-bind:class="{'invalid':<?php echo e($attributes->get('name')); ?>.errorMessage && <?php echo e($attributes->get('name')); ?>.blurred}"
<?php endif; ?>
<?php echo e($attributes->merge(['autocomplete' => 'off',
'class' => 'placeholder-neutral-400 dark:bg-neutral-800 dark:text-neutral-400
dark:placeholder-neutral-500 border border-neutral-300 focus:ring-amber-500 focus:border-amber-500
dark:border-neutral-600 form-input w-full sm:text-sm rounded-md transition ease-in-out duration-100
focus:outline-none shadow-sm bg-opacity-60 dark:bg-opacity-50 '.($inline ? 'inline-block' : 'block')])); ?>>
<?php if($attributes->has('name') && trim($attributes->get('name'))!= ''): ?>
<p x-show="<?php echo e($attributes->get('name')); ?>.errorMessage && <?php echo e($attributes->get('name')); ?>.blurred"
    x-transition.opacity.duration.300ms x-text="<?php echo e($attributes->get('name')); ?>.errorMessage" class="error-message">
<?php endif; ?>
<?php /**PATH C:\laragon\www\JobApplication\resources\views/components/input.blade.php ENDPATH**/ ?>