<div class="fixed bottom-4 right-4 overflow-hidden dark:text-neutral-200 z-50 pt-7 px-6 pb-4 dark:bg-neutral-900
    max-w-75 sm:max-w-sm md:max-w-md w-full rounded-lg shadow-lg bg-gradient-to-tr bg-opacity-90 border-t-4
    border-amber-600 bg-neutral-50" x-data="{'loading':false}" x-init="ready(() => {
        setTimeout(()=>{
            loading = true
        },1000)
    });" x-show="loading" x-transition.opacity.duration.400ms x-transition:leave.opacity.duration.600ms
    style="display: none;">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon.x-circle','data' => ['@click' => 'loading=false','class' => 'w-6 h-6 absolute right-2 top-2 cursor-pointer']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icon.x-circle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['@click' => 'loading=false','class' => 'w-6 h-6 absolute right-2 top-2 cursor-pointer']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php echo e(__("Hi, I'm Hugo Rosas General Manager of Azul Maya Inc. Send me your request and I will contact you as soon as possible.")); ?>

</div>
<?php /**PATH C:\laragon\www\JobApplication\resources\views/components/welcome-alert.blade.php ENDPATH**/ ?>