<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['inline'=>false]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['inline'=>false]); ?>
<?php foreach (array_filter((['inline'=>false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<label <?php echo e($attributes); ?> class="<?php echo e($inline ? 'inline-block' : 'block'); ?> text-sm font-medium text-neutral-700 dark:text-neutral-200">
    <?php echo e($slot); ?>

</label>
<?php /**PATH C:\laragon\www\JobApplication\resources\views/components/label.blade.php ENDPATH**/ ?>