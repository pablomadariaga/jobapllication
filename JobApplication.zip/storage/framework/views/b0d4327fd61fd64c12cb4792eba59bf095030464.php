<div
    style='background-image: url(https://thepineappletequila.com/img/menu-background.jpg);
background-size: cover;
background-position: 25%;
font-family: Roboto, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";'>
    <div style="background-color: #00000080; padding-top:2rem; padding-bottom:2rem;">
        <div style="min-height: 100vh; width: 100%; color: #d4d4d4; position: relative;">
            <div
                style="background-color: #171717cc;border-radius: 0.25rem;padding: 1.25rem; width: 90%; margin-left:2.5%;">
                <table style="margin-bottom: 1rem;font-weight: 600;width: 100%;" class="mb-4 font-semibold w-full">
                    <tr>
                        <td colspan="2" style="font-size: 1.65rem;line-height: 2rem;color: #fafafa;">
                            <?php echo e($user->company->name); ?>

                        </td>
                    </tr>
                    <tr>
                        <td style="font-size: 1.5rem;line-height: 2rem;color: #fafafa;">
                            <?php echo e(__('Application for employment')); ?></td>
                        <td style="text-align: right;color: #fafafa;">
                            <?php echo e(substr($user->created_at,0,10)); ?></td>
                    </tr>
                </table>
                <hr style="border-color: <?php echo e($user->company->color); ?>;margin-bottom: 1.2rem;">
                <table style="color: #fafafa;width: 100%;">
                    <tr>
                        <td colspan="2" style="font-weight: 600;"><?php echo e(__('Personal information')); ?></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="border-bottom: 1px solid <?php echo e($user->company->color); ?>;padding-bottom: 1rem;"></td>
                    </tr>
                    <tr>
                        <td style="padding-top: 1rem;"><?php echo e(__('First name')); ?>:</td>
                        <td style="padding-top: 1rem;"><?php echo e($user->first_name); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Last name')); ?>:</td>
                        <td><?php echo e($user->last_name); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Social security No')); ?>:</td>
                        <td><?php echo e($user->social_security); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Present address')); ?>:</td>
                        <td><?php echo e($user->present_address); ?>

                            <?php echo e($user->present_state); ?>,
                            <?php echo e($user->present_city); ?>. /
                            <?php echo e(__('ZIP Code')); ?>: <?php echo e($user->present_zip); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Phone')); ?>:</td>
                        <td><?php echo e($user->present_phone); ?></td>
                    </tr>
                    
                    <tr>
                        <td><?php echo e(__('Email address')); ?>:</td>
                        <td><?php echo e($user->email); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Referred by')); ?>:</td>
                        <td><?php echo e($user->referred_by); ?></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="border-bottom: 1px solid <?php echo e($user->company->color); ?>;padding-bottom: 1rem;"></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="font-weight: 600;padding-top: 1rem;"><?php echo e(__('Employment desired')); ?></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="border-bottom: 1px solid <?php echo e($user->company->color); ?>;padding-bottom: 1rem;"></td>
                    </tr>
                    <tr>
                        <td style="padding-top: 1rem;"><?php echo e(__('Position')); ?>:</td>
                        <td style="padding-top: 1rem;"><?php echo e($user->position); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Date you can start')); ?>:</td>
                        <td><?php echo e(substr($user->start_date,0,10)); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Are you employed now?')); ?>:</td>
                        <td><?php echo e($user->employed ? __('Yes') : __('No')); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Ever applied to this company before?')); ?>:</td>
                        <td><?php echo e($user->applied ? __('Yes') : __('No')); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Where?')); ?>:</td>
                        <td><?php echo e($user->where_apply); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('When?')); ?>:</td>
                        <td><?php echo e($user->when_apply); ?></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="border-bottom: 1px solid <?php echo e($user->company->color); ?>;padding-bottom: 1rem;"></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="font-weight: 600;padding-top: 1rem;"><?php echo e(__('Education')); ?></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="border-bottom: 1px solid <?php echo e($user->company->color); ?>;padding-bottom: 1rem;"></td>
                    </tr>
                    <tr>
                        <td style="padding-top: 1rem;"><?php echo e(__('High school')); ?>:</td>
                        <td><?php echo e($user->high_school); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Did you graduate?')); ?>:</td>
                        <td><?php echo e($user->high_school_graduate ? __('Yes') : __('No')); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Subjects studied')); ?>:</td>
                        <td><?php echo e($user->high_school_subjects_studied); ?></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="border-bottom: 1px solid <?php echo e($user->company->color); ?>;padding-bottom: 1rem;"></td>
                    </tr>
                    <tr>
                        <td style="padding-top: 1rem;"><?php echo e(__('College')); ?>:</td>
                        <td style="padding-top: 1rem;"><?php echo e($user->college); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Did you graduate?')); ?>:</td>
                        <td><?php echo e($user->college_graduate ? __('Yes') : __('No')); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Subjects studied')); ?>:</td>
                        <td><?php echo e($user->college_subjects_studied); ?></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="border-bottom: 1px solid <?php echo e($user->company->color); ?>;padding-bottom: 1rem;"></td>
                    </tr>
                    <tr>
                        <td style="padding-top: 1rem;"><?php echo e(__('Trade, business, or correspondence school')); ?>:</td>
                        <td style="padding-top: 1rem;"><?php echo e($user->trade_school); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Did you graduate?')); ?>:</td>
                        <td><?php echo e($user->trade_school_graduate ? __('Yes') : __('No')); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Subjects studied')); ?>:</td>
                        <td><?php echo e($user->trade_school_subjects_studied); ?></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="border-bottom: 1px solid <?php echo e($user->company->color); ?>;padding-bottom: 1rem;"></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="font-weight: 600;padding-top: 1rem;"><?php echo e(__('General information')); ?></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="border-bottom: 1px solid <?php echo e($user->company->color); ?>;padding-bottom: 1rem;"></td>
                    </tr>
                    <tr>
                        <td style="padding-top: 1rem;"><?php echo e(__('Subjects of special study or research work')); ?>:</td>
                        <td style="padding-top: 1rem;"><?php echo e($user->special_study); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Special training')); ?>:</td>
                        <td><?php echo e($user->special_training); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Special skills')); ?>:</td>
                        <td><?php echo e($user->special_skills); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('U.S Military service')); ?>:</td>
                        <td><?php echo e($user->military); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Rank')); ?>:</td>
                        <td><?php echo e($user->rank); ?></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="border-bottom: 1px solid <?php echo e($user->company->color); ?>;padding-bottom: 1rem;"></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="font-weight: 600;padding-top: 1rem;"><?php echo e(__('Former employers')); ?></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="border-bottom: 1px solid <?php echo e($user->company->color); ?>;padding-bottom: 1rem;"></td>
                    </tr>
                    <tr>
                        <td style="padding-top: 1rem;"><?php echo e(__('From')); ?>:</td>
                        <td style="padding-top: 1rem;"><?php echo e($user->year_1); ?>

                            <?php echo e($user->month_1); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Name')); ?>:</td>
                        <td><?php echo e($user->name_1); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Address')); ?>:</td>
                        <td><?php echo e($user->address_1); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Position')); ?>:</td>
                        <td><?php echo e($user->position_1); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Reason for leaving')); ?>:</td>
                        <td><?php echo e($user->reason_1); ?></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="border-bottom: 1px solid <?php echo e($user->company->color); ?>;padding-bottom: 1rem;"></td>
                    </tr>
                    <tr>
                        <td style="padding-top: 1rem;"><?php echo e(__('From')); ?>:</td>
                        <td style="padding-top: 1rem;"><?php echo e($user->year_2); ?>

                            <?php echo e($user->month_2); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Name')); ?>:</td>
                        <td><?php echo e($user->name_2); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Address')); ?>:</td>
                        <td><?php echo e($user->address_2); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Position')); ?>:</td>
                        <td><?php echo e($user->position_2); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Reason for leaving')); ?>:</td>
                        <td><?php echo e($user->reason_2); ?></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="border-bottom: 1px solid <?php echo e($user->company->color); ?>;padding-bottom: 1rem;"></td>
                    </tr>
                    <tr>
                        <td style="padding-top: 1rem;"><?php echo e(__('From')); ?>:</td>
                        <td style="padding-top: 1rem;"><?php echo e($user->year_3); ?>

                            <?php echo e($user->month_3); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Name')); ?>:</td>
                        <td><?php echo e($user->name_3); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Address')); ?>:</td>
                        <td><?php echo e($user->address_3); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Position')); ?>:</td>
                        <td><?php echo e($user->position_3); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Reason for leaving')); ?>:</td>
                        <td><?php echo e($user->reason_3); ?></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="border-bottom: 1px solid <?php echo e($user->company->color); ?>;padding-bottom: 1rem;"></td>
                    </tr>
                    <tr>
                        <td style="padding-top: 1rem;"><?php echo e(__('From')); ?>:</td>
                        <td style="padding-top: 1rem;"><?php echo e($user->year_4); ?>

                            <?php echo e($user->month_4); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Name')); ?>:</td>
                        <td><?php echo e($user->name_4); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Address')); ?>:</td>
                        <td><?php echo e($user->address_4); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Position')); ?>:</td>
                        <td><?php echo e($user->position_4); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(__('Reason for leaving')); ?>:</td>
                        <td><?php echo e($user->reason_4); ?></td>
                    </tr>
                </table>
                <hr style="border-color: <?php echo e($user->company->color); ?>;margin-bottom: 1.5rem;">
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\JobApplication\resources\views/emails/application.blade.php ENDPATH**/ ?>