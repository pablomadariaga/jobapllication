[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\laragon\www\JobApplication\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>