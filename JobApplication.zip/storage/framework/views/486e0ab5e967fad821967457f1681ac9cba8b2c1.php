<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['companies' => []]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['companies' => []]); ?>
<?php foreach (array_filter((['companies' => []]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="fixed inset-0 z-50 bg-neutral-100 dark:bg-neutral-900 transition-colors
    duration-300 text-neutral-700 dark:text-neutral-300 bg-opacity-90 dark:bg-opacity-90"
    x-data="{'loading':true, company: false}" x-trap="loading" x-init="
    ready(() => {
        setTimeout(()=>{
            if(selectedCompany){
                loading = false;
            }else{
                company = true;
            }
        },1000)
    });" x-show="loading" x-transition.opacity.duration.400ms x-transition:leave.opacity.duration.1500ms>
    <div class="absolute inset-0" x-show="!company" x-transition.opacity.duration.400ms
        x-transition:leave.opacity.duration.500ms>
        <div class="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 -mt-20 text-amber-500">
            <svg class="spinner w-52 sm:w-64 lg:w-96 xl:w-110 h-auto" viewBox="0 0 50 50">
                <circle class="path" cx="25" cy="25" r="20" fill="none" stroke-width="1"></circle>
            </svg>
        </div>
        <div class="absolute z-10 left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-center">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.application-logo','data' => ['class' => 'w-52 sm:w-64 lg:w-96 xl:w-110 h-auto']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-52 sm:w-64 lg:w-96 xl:w-110 h-auto']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <p class="mt-2 md:text-lg xl:text-2xl">
                <?php echo e(__('Loading')); ?>...
            </p>
        </div>
    </div>
    <div class="absolute inset-0" x-show="company" x-transition.opacity.duration.700ms
        x-transition:leave.opacity.duration.400ms style="display: none;">
        <div class="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-neutral-200 w-11/12">
            <div class="grid grid-cols-1 xs:grid-cols-3 gap-8 sm:gap-14 lg:gap-24 2xl:gap-32
                place-content-center w-fit mx-auto">
                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button @click="selectedCompany = <?php echo e($company->id); ?>; loading = false;"
                    class="text-center p-3 md:p-6 xl:p-10 rounded-md group relative focus:outline-none">
                    <div class="left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-0
                        w-20 sm:w-24 md:w-36 lg:w-40 xl:w-48 transition-all shadow
                        h-20 sm:h-24 md:h-36 lg:h-40 xl:h-48 rounded-full group-focus:opacity-30
                        group-hover:opacity-30 absolute" style="background-color: <?php echo e($company->color); ?>">
                    </div>
                    <div class="relative z-10">
                        <?php if (isset($component)) { $__componentOriginal3bf0a20793be3eca9a779778cf74145887b021b9 = $component; } ?>
<?php $component = Illuminate\View\DynamicComponent::resolve(['component' => 'logo.'.$company->logo] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\DynamicComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-28 sm:w-26 md:w-44 lg:w-52 xl:w-64 h-auto mx-auto']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3bf0a20793be3eca9a779778cf74145887b021b9)): ?>
<?php $component = $__componentOriginal3bf0a20793be3eca9a779778cf74145887b021b9; ?>
<?php unset($__componentOriginal3bf0a20793be3eca9a779778cf74145887b021b9); ?>
<?php endif; ?>
                        <p class="mt-2 md:text-lg xl:text-2xl">
                            <?php echo e($company->name); ?>

                        </p>
                        <div class="h-0.5 transition-width group-hover:w-full w-0 duration-300
                            group-focus:w-full mx-auto"
                            style="background-color: <?php echo e($company->color); ?>">
                        </div>
                    </div>
                </button>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\JobApplication\resources\views/components/loading.blade.php ENDPATH**/ ?>